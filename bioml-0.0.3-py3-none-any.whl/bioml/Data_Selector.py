"""@package docstring
This module contains functions to select the right data from DB
"""

#matrix operations
import pandas as pd

#database operations
import psycopg2

import bioml.DB_connection as DBC
##########################################################################################################################################
# SELECT DATA

#Get databases with subject_info table inside
def get_db_names(params = []):
    """
    get names of databases present in DB with standard "app" structure (with a table 'subject_info' and a table 'experiment_info') 
    :param params: dict with default values: params['dbname'] = postgres, params['user'] = postgres, params['host'] = localhost, params['port'] = 5432
    :return: list of dict containing databases names
    """
    #Get databases names: 
    # Open a cursor to perform database operations

    if params == []:
        params_copy = {
        'dbname': 'postgres',
        'user': 'postgres',
        'host': 'localhost',
        'port': 5432
        }
    else:
        params_copy = {
        'dbname': params['dbname'],
        'user': params['user'],
        'host': params['host'],
        'port': params['port']
        }

    params_copy = params.copy()
    conn = psycopg2.connect(**params)
    cur = conn.cursor()

    # get table names (Correspond to different experiments)
    cur.execute("SELECT datname FROM pg_database WHERE datistemplate = false;")
    DB_list = cur.fetchall()[1:] #1: to remove postgres itself from list
    DB_list_of_dict = []
    for db in DB_list:
        params_copy['dbname'] = db[0]
        conn = psycopg2.connect(**params_copy)

        # Open a cursor to perform database operations
        cur = conn.cursor()

        cur.execute("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' ORDER BY table_schema,table_name")
        rows = cur.fetchall()
        Table_names = [row[0] for row in rows]

        if 'subject_info' in Table_names and 'experiment_info' in Table_names:
            DB_list_of_dict.append({'label': db[0], 'value': db[0]})  
    
    return DB_list_of_dict

#update options of recording dropdown
def get_recordings(params):
    """
    get names of recordings present in database, can be filtered by subjects_id or conditions, 
    subj and cdts are supposed to filter the recording names returned but this functionality is not implemented yet

    :param subj: value of subject in column 'subject_id' to retrieve (not implemented yet)
    :param exp: name of database to retrieve recordings names from
    :param cdts: value of cdt_nb in column 'cdt_nb' to retrieve (not implemented yet)
    :param params: dict with default values: params['dbname'] = postgres, params['user'] = postgres, params['host'] = localhost, params['port'] = 5432
    :return: List of dict containing recordings names filtered by subj and cdts
    """
    if params['dbname'] != [] and  params['dbname'] is not None:

        # Connect to database
        _, _, cur, exp_info, _ = DBC.connect_DB(params)

        #Get all tables in database
        cur.execute("SELECT table_schema,table_name FROM information_schema.tables WHERE table_schema = 'public' ORDER BY table_schema, table_name")
        rows = cur.fetchall()
        Table_names = [row[1] for row in rows]

        try:
            #First try with targets if there are some
            table_to_get_cdts = exp_info[exp_info['is_target'] == True].sort_values(by=['sampling_frequencies'])['stream_names'].values[0]
        except:
            table_to_get_cdts = exp_info[exp_info['is_target'] == False].sort_values(by=['sampling_frequencies'])['stream_names'].values[0]

        #Check that table actually exists
        if table_to_get_cdts.lower() not in Table_names:
            print("\n table does not exists \n")
            return []

        cdt_list_of_dict = []
        cdt_list = []

        cur.execute("SELECT DISTINCT subject_id,condition FROM \"{}\";".format(table_to_get_cdts.lower()))
        all_cdts = cur.fetchall()

        for subject,cdt_nb in all_cdts:
            cdt_list_of_dict.append({'label': "{}_{}".format(subject,cdt_nb), 'value': "{}_{}".format(subject,cdt_nb)})

            # eligible = False
            
            # if subjs == [] or subjs is None:
            #     if cdts == [] or cdts is None:
            #         if cdt_nb not in cdt_list: #check that it was not already added
            #             eligible = True
                        
            #     else:
            #         cdt = cdt_nb.split('_')[0]
            #         if cdt_nb not in cdt_list and cdt in cdts: #check that it was not already added and in the chosen cdts
            #             eligible = True
            # else:
            #     if cdts == [] or cdts is None:
            #         if subject in subjs and cdt_nb not in cdt_list: #check that subject was chosen and that it was not already added
            #             eligible = True

            #     else:
            #         cdt = cdt_nb.split('_')[0]
            #         if subject in subjs and cdt_nb not in cdt_list and cdt in cdts: #check that subject was chosen and cdt was chosen and that it was not already added
            #             eligible = True
                        
            # if eligible is True:
            #     cdt_list_of_dict.append({'label': "{}_{}".format(subject,cdt_nb), 'value': "{}_{}".format(subject,cdt_nb)})
            #     cdt_list.append(cdt_nb)

        return cdt_list_of_dict
    else:
        return []