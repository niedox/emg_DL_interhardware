#Dash imports
import dash
import dash_core_components as dcc
from dash.dependencies import Input, Output, State
import dash_html_components as html
import plotly.graph_objs as go

import plotly.figure_factory as ff

import numpy as np

def violin_div(X1,y, feature_name):
    #Create list for each element of set
    Boxes = []
    for i in set(y): 
        Boxes.append(
            {
                'type': 'violin',
                'x': i,
                'y': X1[np.argwhere(y==i)].reshape(-1,),
                'text': ['Sample'],
                'points': 'all',
                'name' : 'y = ' + str(i)
            }
        )
                    
        
        
    
    return html.Div([dcc.Graph(id='violin_plot', 
                               figure={
                                   'data': Boxes,
                                   'layout': go.Layout(title= 'Violin plot of feature ' + feature_name)
                               })
                   ])













