#Dash imports
import dash
import dash_core_components as dcc
from dash.dependencies import Input, Output, State
import dash_html_components as html
import plotly.graph_objs as go

import numpy as np

def boxplot_div(X,y, feature_name):    
    #Create list for each element of set
    Boxes = []
    for i in set(y):
        Boxes.append(go.Box(y=X[np.argwhere(y==i)].reshape(-1,),
                            name = str(i)
                           )
                    )
    
    return html.Div([dcc.Graph(id='boxplot_plot', 
                               figure={
                                   'data': Boxes,
                                   'layout': go.Layout(title= 'Boxplot of feature ' + feature_name)
                               })
                   ])