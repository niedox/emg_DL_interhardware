#Dash imports
import dash
import dash_core_components as dcc
from dash.dependencies import Input, Output, State
import dash_html_components as html
import plotly.graph_objs as go

import numpy as np

def scatter3D_div(X1, X2, X3, y, feature_name1, feature_name2, feature_name3):
    #Get number of different labels (binary or multiclass)
    nb_class = len(set(y))
    
    #Create colors vectors
    colors = ['rgb('+str(h)+',255'+',0%)' for h in np.linspace(0, 255, nb_class)]
    
    #Create list for each element of set
    Boxes = []
    for idx,i in enumerate(set(y)):
        Boxes.append(go.Scatter3d(x=X1[np.argwhere(y==i)].reshape(-1,),
                                  y=X2[np.argwhere(y==i)].reshape(-1,),
                                  z=X3[np.argwhere(y==i)].reshape(-1,),
                                mode="markers", 
                                name = 'y = ' + str(i)))

    return html.Div([dcc.Graph(id='scatter3D_plot', 
                               figure={
                                   'data': Boxes,
                                   'layout': go.Layout(title= '3D plot of features ' + feature_name1 + ' and ' + 
                                                       feature_name2 + ' and ' + feature_name2,
                                                       scene = dict(
                                                              xaxis = dict( title= feature_name1),
                                                              yaxis = dict( title= feature_name2),
                                                              zaxis = dict( title= feature_name3))
                                                      )
                               })
                   ])