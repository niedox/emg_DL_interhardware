#Dash imports
import dash
import dash_core_components as dcc
from dash.dependencies import Input, Output, State
import dash_html_components as html
import plotly.graph_objs as go

import numpy as np

def label_plot_div(true_targets,predicted_targets, time):
    '''
    Param - true_targets: list containing the true labels
    Param - predicted_targets: list containing the predicted labels
    Return: plot.ly Scatter object to be added into dash graph
    '''

    Boxes = []
    
    Boxes.append(go.Scatter(x=time, y=true_targets,
                                marker={'color': 'green', 'size': 1},
                                name = 'True Targets',
                                fill='tozeroy'
                           ))
    
    Boxes.append(go.Scatter(x=time, y=predicted_targets,
                                marker={'color': 'black', 'size': 1},
                                name = 'Predicted Targets'))
    
    
    
    return dcc.Graph(
        id='label_plot', 
        figure={
            'data': Boxes,
            'layout': go.Layout(title= 'Predicted targets vs Real targets',
            xaxis= dict( title= 'Time'))
        })
                   