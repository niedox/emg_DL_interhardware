from tensorflow.keras.models import Sequential
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Conv2D
from tensorflow.keras.layers import Dense
from tensorflow.keras.layers import ReLU
from tensorflow.keras.layers import Input
from tensorflow.keras.layers import ZeroPadding2D
from tensorflow.keras.layers import AveragePooling2D
from tensorflow.keras.layers import Dropout
from tensorflow.keras.layers import Flatten
from tensorflow.keras.layers import BatchNormalization
from tensorflow.keras.utils import plot_model
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.optimizers import SGD
from tensorflow.keras.regularizers import l2
from tensorflow.keras.callbacks import LearningRateScheduler
from tensorflow.keras import regularizers

import appfunctools.Machine_Learning as ML

import numpy as np

def create_mlp(input_shape, task_type, DNN_shape, optimizer, Nb_outputs,nclass,L1 = 0, L2 = 0):
    #DNN_shape should be a list
    Input_1= Input(shape=(input_shape))



    ######################################## FULLY CONNECTED LAYERS #########################################
    for i,nb_nodes in enumerate(DNN_shape):    
        if i == 0:
            x = Dense(nb_nodes, input_dim=input_shape, activation = 'relu', kernel_regularizer = regularizers.l1_l2(l1=L1, l2=L2))(Input_1)
        else:
           x = Dense(nb_nodes, activation = 'relu')(x)

    #ADD DROPOUT
    #ADD GS

    if task_type == 'Classification':
        if Nb_outputs == 1:
            out = Dense(Nb_outputs,  activation='softmax')(x)
            model = Model(inputs=Input_1, outputs=out)
        else:
            out = Dense(Nb_outputs,  activation='sigmoid')(x)
            model = Model(inputs=Input_1, outputs=out)
            # out = []
            # for i in range(nclass):
            #     out.append(Dense(Nb_outputs,  activation='sigmoid')(x))
            # model = Model(inputs=Input_1, outputs=out)


        if nclass == 2:
            # For a binary classification problem
            model.compile(optimizer=optimizer, loss='binary_crossentropy', metrics=['accuracy'])
        else:
            # For a multi-class classification problem
            model.compile(optimizer=optimizer, loss='categorical_crossentropy', metrics=['accuracy'])
    else:
        out = Dense(Nb_outputs,  activation='relu')(x)
        #print('\n INFO: Activation function of output is RELU')
        model = Model(inputs=Input_1, outputs=out)
    
        # For a mean squared error regression problem
        model.compile(optimizer=optimizer, loss='mse')


    return model

def CreateFit_mlp(x_train,y_train,x_val,y_val,params):
    #This function is made to work with Talos

    #hyperparameters
    DNN_shape = params['DNN_shape']
    lambda1 = params['lambda1']
    lambda2 = params['lambda2']
    callbacks_list = params['callbacks_list']

    # Defining the callbacks we want to use: Decreasing learning rate
    if params['callbacks_list'] is True:
        lrate_callback = LearningRateScheduler(ML.step_decay)
        callbacks_list = [lrate_callback]
    else:
        callbacks_list = None

    input_shape = params['input_shape']
    task_type = params['task_type']
    optimizer = params['optimizer']
    Nb_outputs = params['Nb_outputs']
    nclass = params['nclass']

    model = create_mlp(input_shape, task_type, DNN_shape, optimizer, Nb_outputs,nclass,L1 = lambda1, L2 = lambda2)

    out = model.fit(x_train,y_train, epochs = 50, batch_size = 64, verbose = 0, callbacks = callbacks_list, validation_data = [x_val, y_val])
    
    return out, model



def step_decay(epoch):
    #We half the the learning rate each 10 epochs
    initial_l_r = 0.01 
    drop = 0.5 
    epochs_drop = 10
    lrate = initial_l_r * np.power(drop,np.floor((1 + epoch)/epochs_drop))
    # if you want to avoid the learning rate decay, uncomment this line.
    #lrate = initial_l_r
    #print('The learning rate is : ', lrate)
    return lrate

    
    
    

    
    