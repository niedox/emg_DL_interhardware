"""@package docstring
This module contains the function creating the link with the DB and low level getters for label table and table names in a database
"""

import psycopg2
from sqlalchemy import create_engine
import pandas as pd

import warnings
def connect_DB(params = []):
    """
    Get sqlalchemy engine object, psycopg2 connection and cursor as well as exp_info and sbj_info tables of database named: exp

    :param exp: name of database to retrieve recordings names from
    :param params: dict with default values: params['dbname'] = postgres, params['user'] = postgres, params['host'] = localhost, params['port'] = 5432
    user is always postgres, host is IP adress of database 
    :return: sqlalchemy engine object, psycopg2 connection and cursor as well as exp_info and sbj_info tables
    """
    # Connect to database
    try:
        conn = psycopg2.connect(**params)
        engine = create_engine('postgresql://postgres@{host}:{port}/{DB}'.format(host = params['host'], port = params['port'], DB = params['dbname']))
    except Exception as e:
            raise ValueError('ERROR: critical error while connecting to database: {}'.format(e))

    # Open a cursor to perform database operations
    cur = conn.cursor()

    #Try and except in case they are not in DB will return None
    try:
        exp_info = pd.read_sql_query("select * from experiment_info", engine)
        exp_info = exp_info.set_index('index')
    except:
        exp_info = None

    try:
        subj_info = pd.read_sql_query("select * from subject_info", engine)
        subj_info = subj_info.set_index('index')
    except:
        subj_info = None

    return engine, conn, cur, exp_info, subj_info

#should be in Data_Loader
# def L_extract_data(engine, Table_name, columns, subj = None, cdt_nb = None, rec = None):
#     #Read Database
#     if subj == None and cdt_nb == None and rec != None:
#         warnings.warn('Using Recordings is deprecated please use subject and cdt_nb')
#         data = pd.read_sql_query("SELECT {columns} FROM \"{table}\"  where \"Recording\" = '{rec}' order by index".format(columns = columns,
#                                                                                                                         table = Table_name.lower(), 
#                                                                                                                         rec = rec), engine)
#     elif subj != None and cdt_nb != None and rec == None:
#         data = pd.read_sql_query("SELECT {columns} FROM \"{table}\"  where (subject_id = '{subject}' and condition = '{cdt}') order by index".format(columns = columns,
#                                                                                                                                                         table = Table_name.lower(), 
#                                                                                                                                                         subject = subj, 
#                                                                                                                                                         cdt = cdt_nb), engine)      
#     elif subj == None and cdt_nb == None and rec == None:
#         data = pd.read_sql_query("SELECT {columns} FROM \"{table}\" order by index".format(columns = columns,
#                                                                                        table = Table_name.lower()), engine)  
#     else:
#         raise ValueError('Undefined situation')      

#     data = data.set_index('index')
#     return data

def get_label_table(cur):
    """
    Get label table based on experiment_info table present in database

    :param cur: psycopg2 cursor object
    :return: label table as numpy array (?)
    """
    cur.execute("select stream_names from experiment_info where is_target = True;")
    label_table = cur.fetchall()
    label_table = label_table[0][0]
    return label_table

def get_table_names(cur):
    """
    Get names of tables present in database 
    
    :param cur: psycopg2 cursor object
    :return: list of table names
    """
    # get table names
    cur.execute("SELECT table_schema,table_name FROM information_schema.tables WHERE table_schema = 'public' ORDER BY table_schema,table_name")
    rows = cur.fetchall()
    Table_names = [row[1] for row in rows]
    return Table_names